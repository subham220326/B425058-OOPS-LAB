lab test 6
